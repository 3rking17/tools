import asyncio
import os
import json
import sqlite3
from tqdm import tqdm
from telethon import TelegramClient, events
from telethon.tl.types import MessageMediaPhoto, MessageMediaDocument
import sys

# --- cryptg enforcement (required for max download speed) ---
try:
    import cryptg
except ImportError:
    raise RuntimeError(
        "cryptg is required for high-speed Telegram downloads. Install with: pip install cryptg"
    )

from lib import FastTelethon

# Force unbuffered output
os.environ["PYTHONUNBUFFERED"] = "1"

# Telegram Config
STATE_FILE = 'state.json'

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, 'r') as f:
            return json.load(f)
    return {
        'api_id': None,
        'api_hash': None,
        'phone': None,
        'channels': {},
    }

def save_state(state):
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

state = load_state()

if not state['api_id'] or not state['api_hash'] or not state['phone']:
    state['api_id'] = int(input("Enter API ID: "))
    state['api_hash'] = input("Enter API Hash: ")
    state['phone'] = input("Enter phone number: ")
    save_state(state)

client = TelegramClient('session_cpanel', state['api_id'], state['api_hash'])

async def download_media(channel_name, message):
    import uuid
    import shutil
    media_dir = os.path.join("downloads", channel_name)
    os.makedirs(media_dir, exist_ok=True)

    # Check disk space (require at least 1 GB free)
    total, used, free = shutil.disk_usage(media_dir)
    if free < 1_000_000_000:
        tqdm.write(f"[!] Insufficient disk space for message {message.id}: {free / (1024**3):.2f} GB free")
        return None

    if hasattr(message.media, 'document'):
        total_size = message.media.document.size
        file_name = f"{message.media.document.attributes[-1].file_name.rsplit('.', 1)[0]}_{message.id}.txt"
        file_path = os.path.join(media_dir, file_name)
    elif hasattr(message.media, 'photo'):
        total_size = message.media.photo.sizes[-1].size
        file_name = f"photo_{message.id}.jpg"
        file_path = os.path.join(media_dir, file_name)
    else:
        tqdm.write(f"[!] Unsupported media type for message {message.id}")
        return None

    if os.path.exists(file_path):
        tqdm.write(f"[!] File {file_path} already exists, skipping download")
        return file_path

    progress_bar = None
    def progress_callback(current, total):
        nonlocal progress_bar
        if progress_bar is None and total != 0:
            progress_bar = tqdm(total=total, unit='B', unit_scale=True, desc="Downloading", leave=True, mininterval=0.5)
        if progress_bar:
            progress_bar.n = current
            progress_bar.refresh()

    try:
        # --- FastTelethon: high-speed chunked download ---
        if hasattr(message.media, 'document'):
            # Document download via FastTelethon
            with open(file_path, "wb") as out_f:
                await FastTelethon.download_file(client, message.document, out_f, progress_callback)
        elif hasattr(message.media, 'photo'):
            # Photo: FastTelethon doesn't handle InputPhotoFileLocation well,
            # fall back to standard download for photos (typically small files)
            downloaded = await message.download_media(file=file_path, progress_callback=progress_callback)
            if downloaded:
                file_path = downloaded
            else:
                tqdm.write(f"[!] Photo download returned None for message {message.id}")
                return None
        else:
            tqdm.write(f"[!] Unsupported media type for message {message.id}")
            return None
    except Exception as e:
        tqdm.write(f"[!] Error downloading media for message {message.id}: {e}")
        return None

    if progress_bar:
        progress_bar.n = progress_bar.total or progress_bar.n
        progress_bar.refresh()
        progress_bar.close()

    if file_path and file_path.endswith('.txt'):
        tqdm.write(f"[+] Downloaded: {file_path}")
        wordpress_lines = []
        cpanel_lines = []
        plesk_lines = []
        moodle_lines = []
        evopanel_lines = []
        whmcs_lines = []
        joomla_lines = []
        cyberpanel_lines = []
        wordpress_keywords = ["wp-admin", "wp-login.php"]
        cpanel_keywords = [":2082", ":2083", ":2087"]
        plesk_keywords = ["login_up.php"]
        moodle_keywords = ["/login/index.php"]
        evopanel_keywords = ["/evo/login"]
        whmcs_keywords = ["clientarea.php"]
        joomla_keywords = ["/administrator/index.php"]
        cyberpanel_keywords = [":8090", ":admin:"]
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    # Add https:// if line doesn't start with http:// or https://
                    if not line.startswith(('http://', 'https://')):
                        parts = line.split(":", 2)
                        if len(parts) >= 2:
                            url = f"https://{parts[0]}" + (":" + parts[1] if len(parts) > 1 else "")
                            line = url + ":" + parts[-1] if len(parts) == 3 else line
                    if any(keyword in line for keyword in wordpress_keywords):
                        wordpress_lines.append(line)
                    if any(keyword in line for keyword in cpanel_keywords):
                        cpanel_lines.append(line)
                    if any(keyword in line for keyword in plesk_keywords):
                        plesk_lines.append(line)
                    if any(keyword in line for keyword in moodle_keywords):
                        moodle_lines.append(line)
                    if any(keyword in line for keyword in evopanel_keywords):
                        evopanel_lines.append(line)
                    if any(keyword in line for keyword in whmcs_keywords):
                        whmcs_lines.append(line)
                    if any(keyword in line for keyword in joomla_keywords):
                        joomla_lines.append(line)
                    if any(keyword in line for keyword in cyberpanel_keywords):
                        cyberpanel_lines.append(line)
            if wordpress_lines:
                os.makedirs("Filter/Wordpress-Filter", exist_ok=True)
                wordpress_uuid = str(uuid.uuid4())
                wordpress_dest = os.path.join("Filter/Wordpress-Filter", f"RANDOM-UUID-{wordpress_uuid}.txt")
                with open(wordpress_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in wordpress_lines)
                tqdm.write(f"[+] Wordpress filtered file saved: {wordpress_dest} ({len(wordpress_lines)} lines matched)")

            if cpanel_lines:
                os.makedirs("Filter/Cpanel-Filter", exist_ok=True)
                cpanel_uuid = str(uuid.uuid4())
                cpanel_dest = os.path.join("Filter/Cpanel-Filter", f"RANDOM-UUID-{cpanel_uuid}.txt")
                with open(cpanel_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in cpanel_lines)
                tqdm.write(f"[+] Cpanel filtered file saved: {cpanel_dest} ({len(cpanel_lines)} lines matched)")

            if plesk_lines:
                os.makedirs("Filter/Plesk-Filter", exist_ok=True)
                plesk_uuid = str(uuid.uuid4())
                plesk_dest = os.path.join("Filter/Plesk-Filter", f"RANDOM-UUID-{plesk_uuid}.txt")
                with open(plesk_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in plesk_lines)
                tqdm.write(f"[+] Plesk filtered file saved: {plesk_dest} ({len(plesk_lines)} lines matched)")

            if moodle_lines:
                os.makedirs("Filter/Moodle-Filter", exist_ok=True)
                moodle_uuid = str(uuid.uuid4())
                moodle_dest = os.path.join("Filter/Moodle-Filter", f"RANDOM-UUID-{moodle_uuid}.txt")
                with open(moodle_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in moodle_lines)
                tqdm.write(f"[+] Moodle filtered file saved: {moodle_dest} ({len(moodle_lines)} lines matched)")

            if evopanel_lines:
                os.makedirs("Filter/Evopanel-Filter", exist_ok=True)
                evopanel_uuid = str(uuid.uuid4())
                evopanel_dest = os.path.join("Filter/Evopanel-Filter", f"RANDOM-UUID-{evopanel_uuid}.txt")
                with open(evopanel_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in evopanel_lines)
                tqdm.write(f"[+] Evopanel filtered file saved: {evopanel_dest} ({len(evopanel_lines)} lines matched)")

            if whmcs_lines:
                os.makedirs("Filter/WHMCS-Filter", exist_ok=True)
                whmcs_uuid = str(uuid.uuid4())
                whmcs_dest = os.path.join("Filter/WHMCS-Filter", f"RANDOM-UUID-{whmcs_uuid}.txt")
                with open(whmcs_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in whmcs_lines)
                tqdm.write(f"[+] WHMCS filtered file saved: {whmcs_dest} ({len(whmcs_lines)} lines matched)")

            if joomla_lines:
                os.makedirs("Filter/Joomla-Filter", exist_ok=True)
                joomla_uuid = str(uuid.uuid4())
                joomla_dest = os.path.join("Filter/Joomla-Filter", f"RANDOM-UUID-{joomla_uuid}.txt")
                with open(joomla_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in joomla_lines)
                tqdm.write(f"[+] Joomla filtered file saved: {joomla_dest} ({len(joomla_lines)} lines matched)")

            if cyberpanel_lines:
                os.makedirs("Filter/Cyberpanel-Filter", exist_ok=True)
                cyberpanel_uuid = str(uuid.uuid4())
                cyberpanel_dest = os.path.join("Filter/Cyberpanel-Filter", f"RANDOM-UUID-{cyberpanel_uuid}.txt")
                with open(cyberpanel_dest, "w", encoding="utf-8") as out_f:
                    out_f.writelines(line + "\n" for line in cyberpanel_lines)
                tqdm.write(f"[+] Cyberpanel filtered file saved: {cyberpanel_dest} ({len(cyberpanel_lines)} lines matched)")

        except Exception as e:
            tqdm.write(f"[!] Error filtering {file_path}: {e}")

    return file_path

def save_metadata(channel_id, message, media_path):
    db_path = os.path.join("database", str(channel_id), "messages.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    for attempt in range(3):
        try:
            conn = sqlite3.connect(db_path, timeout=10)
            c = conn.cursor()
            c.execute('''
                CREATE TABLE IF NOT EXISTS files (
                    message_id INTEGER PRIMARY KEY,
                    date TEXT,
                    file_path TEXT
                )
            ''')
            c.execute('INSERT OR IGNORE INTO files VALUES (?, ?, ?)', (
                message.id,
                message.date.strftime('%Y-%m-%d %H:%M:%S'),
                media_path
            ))
            conn.commit()
            conn.close()
            tqdm.write(f"[*] Metadata saved for message {message.id} in {db_path}")
            return
        except sqlite3.OperationalError as e:
            if attempt < 2:
                asyncio.sleep(1)
            else:
                tqdm.write(f"[!] Failed to save metadata for message {message.id} after 3 attempts: {e}")

@client.on(events.NewMessage)
async def telegram_handler(event):
    msg = event.message
    chat_id = str(event.chat_id)
    if chat_id not in state['channels']:
        return  # Silently ignore non-active channels
    try:
        tqdm.write(f"[DEBUG] Detected message {msg.id} from channel {chat_id}")
        db_path = os.path.join("database", str(chat_id), "messages.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        try:
            conn = sqlite3.connect(db_path, timeout=10)
            c = conn.cursor()
            c.execute('''
                CREATE TABLE IF NOT EXISTS files (
                    message_id INTEGER PRIMARY KEY,
                    date TEXT,
                    file_path TEXT
                )
            ''')
            conn.commit()
            c.execute('SELECT message_id FROM files WHERE message_id = ?', (msg.id,))
            if c.fetchone():
                conn.close()
                return  # Silently skip already processed messages
            conn.close()
        except sqlite3.OperationalError as e:
            tqdm.write(f"[!] Database error for message {msg.id}: {e}")
            return

        chat = await event.get_chat()
        if hasattr(chat, 'title'):
            channel_name = chat.title.replace(" ", "_")
        else:
            channel_name = (chat.first_name or "") + (chat.last_name or "")
            if not channel_name and chat.username:
                channel_name = chat.username
            if not channel_name:
                channel_name = f"user_{chat_id}"

        if isinstance(msg.media, (MessageMediaPhoto, MessageMediaDocument)):
            media_path = await download_media(channel_name, msg)
            if media_path:
                save_metadata(chat_id, msg, media_path)
        else:
            tqdm.write(f"[!] No media in message {msg.id} from {channel_name}")
    except Exception as e:
        tqdm.write(f"[!] Error processing message {msg.id}: {e}")

async def main_loop():
    try:
        for attempt in range(3):
            try:
                await client.start(phone=state['phone'])
                tqdm.write("[*] Connected to Telegram.")
                break
            except Exception as e:
                tqdm.write(f"[!] Connection error: {e}. Retrying in 5 seconds...")
                if attempt < 2:
                    await asyncio.sleep(5)
                else:
                    tqdm.write("[!] Failed to connect to Telegram after 3 attempts.")
                    return
        if not state['channels']:
            tqdm.write("No channels specified. Please add them first.")
            return
        client.add_event_handler(telegram_handler, events.NewMessage(chats=list(map(int, state['channels'].keys()))))
        tqdm.write("📥 Listening for Telegram messages...")
        while True:
            try:
                await client.run_until_disconnected()
            except Exception as e:
                tqdm.write(f"[!] Disconnected: {e}. Reconnecting in 60 seconds...")
                await asyncio.sleep(60)
                for attempt in range(3):
                    try:
                        await client.start(phone=state['phone'])
                        tqdm.write("[*] Reconnected to Telegram.")
                        break
                    except Exception as e:
                        tqdm.write(f"[!] Reconnection error: {e}")
                        if attempt < 2:
                            await asyncio.sleep(5)
                        else:
                            tqdm.write("[!] Failed to reconnect after 3 attempts.")
                            return
                client.remove_event_handler(telegram_handler)
                client.add_event_handler(telegram_handler, events.NewMessage(chats=list(map(int, state['channels'].keys()))))
                tqdm.write("📥 Reconnected and listening for Telegram messages...")
    except Exception as e:
        tqdm.write(f"[!] Fatal error in main loop: {e}")

def add_channel():
    channel_id = input("Enter channel/user ID (numeric): ").strip()
    if not channel_id.lstrip('-').isdigit():
        tqdm.write("[!] Channel/User ID must be numeric.")
        return
    name = input("Enter channel/user name (for display): ").strip()
    state['channels'][channel_id] = name
    save_state(state)
    client.remove_event_handler(telegram_handler)
    client.add_event_handler(telegram_handler, events.NewMessage(chats=list(map(int, state['channels'].keys()))))
    tqdm.write(f"[✓] Channel/User {channel_id} ({name}) added and event handler updated.")

def remove_channel():
    if not state['channels']:
        tqdm.write("No channels to remove.")
        return
    tqdm.write("Channels:")
    for cid, name in state['channels'].items():
        tqdm.write(f" - {cid}: {name}")
    channel_id = input("Enter channel ID to remove: ").strip()
    if channel_id in state['channels']:
        del state['channels'][channel_id]
        save_state(state)
        client.remove_event_handler(telegram_handler)
        client.add_event_handler(telegram_handler, events.NewMessage(chats=list(map(int, state['channels'].keys()))))
        tqdm.write(f"[✓] Channel {channel_id} removed and event handler updated.")
    else:
        tqdm.write("[!] Channel not found.")

def list_channels():
    if not state['channels']:
        tqdm.write("No channels added.")
        return
    tqdm.write("Channels:")
    for cid, name in state['channels'].items():
        tqdm.write(f" - {cid}: {name}")

def main_menu():
    while True:
        tqdm.write("\n=== Telegram Downloader Tool ===")
        tqdm.write("1. Add Channel ID")
        tqdm.write("2. Remove Channel ID")
        tqdm.write("3. List Channels")
        tqdm.write("4. Start Telegram Processing")
        tqdm.write("0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == '1':
            add_channel()
        elif choice == '2':
            remove_channel()
        elif choice == '3':
            list_channels()
        elif choice == '4':
            try:
                loop = asyncio.get_event_loop()
                loop.run_until_complete(main_loop())
            except Exception as e:
                tqdm.write(f"[!] Error running main loop: {e}")
        elif choice == '0':
            tqdm.write("Exiting.")
            break
        else:
            tqdm.write("[!] Invalid option.")

if __name__ == "__main__":
    asyncio.run(main_menu())